﻿(function () {
    "use strict";

    // How often to send a keepalive heartbeat via SignalR (ms).
    var HEARTBEAT_INTERVAL_MS = 20000;

    function getConfig() {
        return window.chatConfig || { username: "Guest", room: "General" };
    }

    // -------------------------------------------------------------------------
    // SignalR connection
    // -------------------------------------------------------------------------

    var connection = null;
    var heartbeatTimer = null;
    var reconnectTimer = null;
    var isIntentionallyStopped = false;

    function buildConnection() {
        return new signalR.HubConnectionBuilder()
            .withUrl("/chatHub")
            .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
            .configureLogging(signalR.LogLevel.Warning)
            .build();
    }

    // -------------------------------------------------------------------------
    // UI helpers
    // -------------------------------------------------------------------------

    function renderMembers(data) {
        var memberList = document.querySelector(".member-list");
        if (!memberList) return;

        var countEl = document.querySelector(".online-count");
        if (countEl) countEl.textContent = data.onlineCount;

        if (!data.members || data.members.length === 0) {
            memberList.innerHTML = '<div class="empty-members-state">No members to display.</div>';
            return;
        }

        // Online users first, then alphabetical within each group
        var sorted = data.members.slice().sort(function (a, b) {
            if (a.isOnline !== b.isOnline) return a.isOnline ? -1 : 1;
            return a.username.localeCompare(b.username);
        });

        memberList.innerHTML = sorted.map(function (m) {
            var cls = "member-item " + (m.isOnline ? "member-online" : "member-offline");
            return '<div class="' + cls + '">' +
                '<span class="member-status-dot"></span>' +
                '<span class="member-name">' + escapeHtml(m.username) + "</span>" +
                "</div>";
        }).join("");
    }

    function appendMessage(msg) {
        var panel = document.getElementById("chatMessagePanel");
        if (!panel) return;

        var cfg = getConfig();
        // SignalR serialises C# PascalCase → camelCase for JS
        var sender = msg.username || msg.Username || "";
        var text = msg.message || msg.Message || "";
        var tsRaw = msg.timestampUtc || msg.TimestampUtc || new Date().toISOString();

        var isMine = sender.toLowerCase() === cfg.username.toLowerCase();
        var initial = sender ? sender.charAt(0).toUpperCase() : "?";
        var ts = new Date(tsRaw);
        var timeStr = pad(ts.getHours()) + ":" + pad(ts.getMinutes()) + ":" + pad(ts.getSeconds());

        var html = '<div class="message-row ' + (isMine ? "mine" : "theirs") + '">' +
            '<div class="message-avatar">' + escapeHtml(initial) + "</div>" +
            '<div class="message-block">' +
            '<div class="message-meta">' +
            '<span class="message-user">' + escapeHtml(sender) + "</span>" +
            '<span class="message-time">' + timeStr + "</span>" +
            "</div>" +
            '<div class="message-bubble ' + (isMine ? "mine" : "other") + '">' + escapeHtml(text) + "</div>" +
            "</div>" +
            "</div>";

        var empty = panel.querySelector(".empty-chat-state");
        if (empty) empty.remove();

        panel.insertAdjacentHTML("beforeend", html);
        panel.scrollTop = panel.scrollHeight;
    }

    function updateRabbitStatus(isConnected) {
        var el = document.querySelector(".rabbit-status");
        if (el) el.textContent = isConnected ? "Connected" : "Disconnected";
    }

    function updateUnreadBadges(counts) {
        document.querySelectorAll(".unread-badge").forEach(function (el) {
            el.style.display = "none";
            el.textContent = "";
        });
        if (!counts) return;
        Object.keys(counts).forEach(function (room) {
            var count = counts[room];
            if (count > 0) {
                var badge = document.getElementById("badge-" + room);
                if (badge) {
                    badge.textContent = count > 99 ? "99+" : count;
                    badge.style.display = "inline-block";
                }
            }
        });
    }

    function updateRoomList(rooms) {
        var roomList = document.getElementById("roomList");
        if (!roomList || !rooms) return;

        var cfg = getConfig();
        roomList.innerHTML = rooms.map(function (r) {
            var isActive = r.name.toLowerCase() === cfg.room.toLowerCase();
            var tag = r.isPrivate ? '<span class="room-tag">Private</span>' : "";
            return '<form method="post" action="/Chat?handler=JoinRoom" class="room-form">' +
                '<input type="hidden" name="roomName" value="' + escapeHtml(r.name) + '" />' +
                '<button type="submit" class="room-button' + (isActive ? " active" : "") + '">' +
                '<span class="room-left">' +
                '<span class="room-hash">#</span>' +
                '<span class="room-name">' + escapeHtml(r.name) + "</span>" +
                "</span>" +
                '<span class="room-right">' + tag +
                '<span class="unread-badge" id="badge-' + escapeHtml(r.name) + '" style="display:none"></span>' +
                "</span>" +
                "</button></form>";
        }).join("");
    }

    function updateTypingIndicator(data) {
        var cfg = getConfig();
        var indicator = document.getElementById("typingIndicator");
        var label = document.getElementById("typingLabel");
        if (!indicator || !label) return;

        // Filter out the current user from the typers list
        var others = (data.typers || []).filter(function (u) {
            return u.toLowerCase() !== cfg.username.toLowerCase();
        });

        if (others.length === 0) {
            indicator.style.display = "none";
            label.textContent = "";
        } else {
            var text;
            if (others.length === 1) {
                text = others[0] + " is typing…";
            } else if (others.length === 2) {
                text = others[0] + " and " + others[1] + " are typing…";
            } else {
                text = others.length + " people are typing…";
            }
            label.textContent = text;
            indicator.style.display = "flex";
        }
    }

    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    function pad(n) { return n.toString().padStart(2, "0"); }

    // -------------------------------------------------------------------------
    // Heartbeat — keeps _lastSeen fresh on the server
    // -------------------------------------------------------------------------

    function sendHeartbeat() {
        if (!connection || connection.state !== signalR.HubConnectionState.Connected) return;
        var cfg = getConfig();
        connection.invoke("Heartbeat", cfg.username, cfg.room).catch(function () { });
    }

    function startHeartbeatTimer() {
        stopHeartbeatTimer();
        sendHeartbeat();
        heartbeatTimer = window.setInterval(sendHeartbeat, HEARTBEAT_INTERVAL_MS);
    }

    function stopHeartbeatTimer() {
        if (heartbeatTimer !== null) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
    }

    // -------------------------------------------------------------------------
    // Connection lifecycle
    // -------------------------------------------------------------------------

    async function startConnection() {
        if (isIntentionallyStopped) return;

        connection = buildConnection();

        connection.on("PresenceUpdated", function (data) { renderMembers(data); });
        connection.on("RabbitStatusUpdated", function (isConnected) { updateRabbitStatus(isConnected); });
        connection.on("UnreadCountsUpdated", function (counts) { updateUnreadBadges(counts); });
        connection.on("RoomsUpdated", function (rooms) { updateRoomList(rooms); });

        connection.on("RoomOpened", function (data) {
            var countEl = document.querySelector(".online-count");
            if (countEl) countEl.textContent = data.usersOnline;
        });

        connection.on("TypingUpdated", function (data) { updateTypingIndicator(data); });

        connection.on("ReceiveMessage", function (msg) {
            var sender = msg.username || msg.Username || "";
            var text = msg.message || msg.Message || "";

            // If we already rendered this message optimistically, consume the
            // dedup token and skip the server echo to avoid a duplicate bubble.
            var cfg = getConfig();
            if (sender.toLowerCase() === cfg.username.toLowerCase()) {
                var dedupKey = sender.toLowerCase() + "|" + text;
                if (_optimisticKeys[dedupKey] > 0) {
                    _optimisticKeys[dedupKey]--;
                    if (_optimisticKeys[dedupKey] === 0) delete _optimisticKeys[dedupKey];
                    return;
                }
            }

            appendMessage(msg);
        });

        // Replaces the panel with the full history pushed by the server on join.
        // This ensures late joiners and users on a different instance see all
        // messages that arrived via RabbitMQ before they connected.
        connection.on("HistoryLoaded", function (items) {
            var panel = document.getElementById("chatMessagePanel");
            if (!panel) return;

            var cfg = getConfig();
            panel.innerHTML = "";

            items.forEach(function (item) {
                // Status events (e.g. "Alice created the room")
                if ((item.itemType || item.ItemType) === "status") {
                    var statusText = item.statusText || item.StatusText || "";
                    if (statusText) {
                        var div = document.createElement("div");
                        div.className = "status-event";
                        div.textContent = statusText;
                        panel.appendChild(div);
                    }
                    return;
                }

                var sender = item.username || item.Username || "";
                var text = item.message || item.Message || "";
                var tsRaw = item.timestampUtc || item.TimestampUtc || new Date().toISOString();
                if (!text) return;

                var isMine = sender.toLowerCase() === cfg.username.toLowerCase();
                var initial = sender ? sender.charAt(0).toUpperCase() : "?";
                var ts = new Date(tsRaw);
                var timeStr = pad(ts.getHours()) + ":" + pad(ts.getMinutes()) + ":" + pad(ts.getSeconds());

                panel.insertAdjacentHTML("beforeend",
                    '<div class="message-row ' + (isMine ? "mine" : "theirs") + '">' +
                    '<div class="message-avatar">' + escapeHtml(initial) + "</div>" +
                    '<div class="message-block">' +
                    '<div class="message-meta">' +
                    '<span class="message-user">' + escapeHtml(sender) + "</span>" +
                    '<span class="message-time">' + timeStr + "</span>" +
                    "</div>" +
                    '<div class="message-bubble ' + (isMine ? "mine" : "other") + '">' + escapeHtml(text) + "</div>" +
                    "</div></div>");
            });

            panel.scrollTop = panel.scrollHeight;
        });

        connection.onreconnecting(function () {
            stopHeartbeatTimer();
        });

        connection.onreconnected(function () {
            var cfg = getConfig();
            var panel = document.getElementById("chatMessagePanel");
            if (panel) panel.innerHTML = "";
            connection.invoke("RegisterConnection", cfg.username).catch(function () { });
            connection.invoke("OpenRoom", cfg.room, cfg.username).catch(function () { });
            startHeartbeatTimer();
        });

        connection.onclose(function () {
            stopHeartbeatTimer();
            if (!isIntentionallyStopped) {
                reconnectTimer = window.setTimeout(startConnection, 5000);
            }
        });

        try {
            await connection.start();
            var cfg = getConfig();

            // Wipe the server-rendered message HTML immediately so that when
            // HistoryLoaded arrives it is the only source of truth.
            // This prevents duplicates when the page renders messages server-side
            // AND SignalR pushes the same history via HistoryLoaded.
            var panel = document.getElementById("chatMessagePanel");
            if (panel) panel.innerHTML = "";

            await connection.invoke("RegisterConnection", cfg.username);
            await connection.invoke("OpenRoom", cfg.room, cfg.username);
            startHeartbeatTimer();
        } catch (err) {
            console.error("[CHAT] Connection failed:", err);
            stopHeartbeatTimer();
            if (!isIntentionallyStopped) {
                reconnectTimer = window.setTimeout(startConnection, 5000);
            }
        }
    }

    function stopConnection() {
        isIntentionallyStopped = true;
        stopHeartbeatTimer();
        if (reconnectTimer !== null) { clearTimeout(reconnectTimer); reconnectTimer = null; }
        if (connection) connection.stop();
    }

    // -------------------------------------------------------------------------
    // Typing indicator — debounced StartTyping / StopTyping invocations.
    // -------------------------------------------------------------------------

    var _typingTimer = null;
    var _isTyping = false;
    var TYPING_STOP_DELAY_MS = 2000;

    function notifyStartTyping() {
        if (!connection || connection.state !== signalR.HubConnectionState.Connected) return;
        if (!_isTyping) {
            _isTyping = true;
            var cfg = getConfig();
            connection.invoke("StartTyping", cfg.room, cfg.username).catch(function () { });
        }
        // Reset the stop timer on every keystroke
        if (_typingTimer !== null) clearTimeout(_typingTimer);
        _typingTimer = setTimeout(notifyStopTyping, TYPING_STOP_DELAY_MS);
    }

    function notifyStopTyping() {
        if (_typingTimer !== null) { clearTimeout(_typingTimer); _typingTimer = null; }
        if (!_isTyping) return;
        _isTyping = false;
        if (!connection || connection.state !== signalR.HubConnectionState.Connected) return;
        var cfg = getConfig();
        connection.invoke("StopTyping", cfg.room, cfg.username).catch(function () { });
    }

    // -------------------------------------------------------------------------
    // Send — event delegation so no timing issues.
    //
    // Optimistic rendering: the sender's own message is appended immediately
    // without waiting for the server echo, so it appears instant. The dedup
    // map (_optimisticKeys) prevents a duplicate bubble when the ReceiveMessage
    // echo arrives back from the server.
    // -------------------------------------------------------------------------

    // Tracks messages we've already rendered optimistically (key = "user|text")
    // so the server echo via ReceiveMessage doesn't produce a duplicate bubble.
    var _optimisticKeys = {};

    function trySend() {
        var input = document.getElementById("messageTextInput");
        if (!input) return;
        var text = input.value.trim();
        if (!text) return;
        if (!connection || connection.state !== signalR.HubConnectionState.Connected) return;

        var cfg = getConfig();

        // Stop the typing indicator immediately on send
        notifyStopTyping();

        // Render the sender's own message immediately — don't wait for the
        // server echo, which may be missed if the SignalR group assignment
        // hasn't completed yet (root cause: only other users' posts appeared
        // on screen; own posts only showed after a page refresh).
        var dedupKey = cfg.username.toLowerCase() + "|" + text;
        _optimisticKeys[dedupKey] = (_optimisticKeys[dedupKey] || 0) + 1;
        appendMessage({
            username: cfg.username,
            message: text,
            timestampUtc: new Date().toISOString()
        });

        connection.invoke("SendMessage", cfg.room, cfg.username, text)
            .catch(function (err) { console.error("[CHAT] SendMessage failed:", err); });

        input.value = "";
        input.focus();
    }

    document.addEventListener("click", function (e) {
        var t = e.target;
        while (t && t !== document) {
            if (t.id === "sendMessageBtn") { e.preventDefault(); trySend(); return; }
            t = t.parentElement;
        }
    });

    document.addEventListener("keydown", function (e) {
        if (e.target && e.target.id === "messageTextInput") {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                trySend();
            } else if (e.key.length === 1 || e.key === "Backspace" || e.key === "Delete") {
                // Only notify typing on printable keys or edits
                notifyStartTyping();
            }
        }
    });

    // -------------------------------------------------------------------------
    // Page unload — use sendBeacon (HTTP) not SignalR invoke.
    //
    // SignalR invoke() is async and the browser closes the WebSocket before the
    // frame can be flushed during beforeunload. navigator.sendBeacon() is the
    // only browser API guaranteed to complete after the page starts unloading.
    // The server handles it via OnPostBeacon (a Razor Page POST handler).
    // -------------------------------------------------------------------------

    window.addEventListener("beforeunload", function () {
        notifyStopTyping();
        var cfg = getConfig();
        var payload = JSON.stringify({ username: cfg.username, room: cfg.room });
        navigator.sendBeacon("/Chat?handler=Beacon", new Blob([payload], { type: "application/json" }));
        stopConnection();
    });

    window.addEventListener("focus", function () {
        if (connection && connection.state === signalR.HubConnectionState.Connected) {
            sendHeartbeat();
        }
    });

    // Boot
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", startConnection);
    } else {
        startConnection();
    }

})();