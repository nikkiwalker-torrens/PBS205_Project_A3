﻿using ChatClient.Web.Models;
using ChatClient.Web.Services;
using Microsoft.AspNetCore.SignalR;
using System.Collections.Concurrent;

namespace ChatClient.Web.Hubs;

public class ChatHub : Hub
{
    private readonly IChatStateService _chatStateService;
    private readonly IRabbitMqChatService _rabbitMqChatService;

    private const string UsernameKey = "username";
    private const string RoomKey = "room";

    // -------------------------------------------------------------------------
    // Connection registry — maps username → set of active connection IDs.
    // Used so the page handler can push a RoomsUpdated event to a specific user
    // when they are invited to a private room, without knowing their connection ID.
    // Static + lock is safe here because ChatHub is transient (new instance per call)
    // but we need the map to outlive individual hub instances.
    // -------------------------------------------------------------------------
    private static readonly Dictionary<string, HashSet<string>> _userConnections
        = new(StringComparer.OrdinalIgnoreCase);
    private static readonly object _registryLock = new();

    public static IReadOnlyList<string> GetConnectionIds(string username)
    {
        lock (_registryLock)
        {
            return _userConnections.TryGetValue(username, out var ids)
                ? ids.ToList()
                : Array.Empty<string>();
        }
    }

    public ChatHub(IChatStateService chatStateService, IRabbitMqChatService rabbitMqChatService)
    {
        _chatStateService = chatStateService;
        _rabbitMqChatService = rabbitMqChatService;
    }

    // -------------------------------------------------------------------------
    // RegisterConnection — called immediately after the client connects.
    // -------------------------------------------------------------------------

    public async Task RegisterConnection(string username)
    {
        if (string.IsNullOrWhiteSpace(username))
            return;

        username = username.Trim();
        Context.Items[UsernameKey] = username;
        _chatStateService.UpdateLastSeen(username, DateTime.UtcNow);

        // Track this connection ID against the username
        lock (_registryLock)
        {
            if (!_userConnections.TryGetValue(username, out var ids))
            {
                ids = new HashSet<string>();
                _userConnections[username] = ids;
            }
            ids.Add(Context.ConnectionId);
        }

        // Push current RabbitMQ status so the footer is accurate immediately
        var isConnected = await _chatStateService.IsConnectedAsync();
        await Clients.Caller.SendAsync("RabbitStatusUpdated", isConnected);
    }

    // -------------------------------------------------------------------------
    // OpenRoom — join a SignalR group and broadcast updated presence.
    // -------------------------------------------------------------------------

    public async Task OpenRoom(string room, string username)
    {
        room = string.IsNullOrWhiteSpace(room) ? "General" : room.Trim();
        username = string.IsNullOrWhiteSpace(username) ? "Guest" : username.Trim();

        if (!_chatStateService.CanUserAccessRoom(username, room))
            room = "General";

        if (Context.Items.TryGetValue(RoomKey, out var prev) &&
            prev is string prevRoom &&
            !string.Equals(prevRoom, room, StringComparison.OrdinalIgnoreCase))
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, prevRoom);
        }

        Context.Items[UsernameKey] = username;
        Context.Items[RoomKey] = room;

        await Groups.AddToGroupAsync(Context.ConnectionId, room);

        _chatStateService.JoinRoom(username, room);
        _chatStateService.UpdateLastSeen(username, DateTime.UtcNow);

        await Clients.Caller.SendAsync("RoomOpened", new
        {
            room,
            usersOnline = _chatStateService.GetOnlineUserCount(room)
        });

        await BroadcastPresenceAsync(room);

        // Push the full room history to the joining client so they see all
        // messages that arrived via RabbitMQ before they connected, including
        // messages from other server instances.
        var history = _chatStateService.GetVisibleRoomHistory(room, username);
        await Clients.Caller.SendAsync("HistoryLoaded", history);

        // Publish to RabbitMQ so instances on other networks update their LastSeen
        // and re-broadcast PresenceUpdated to their own local SignalR clients.
        try
        {
            await _rabbitMqChatService.PublishPresenceAsync(new PresenceMessage
            {
                Room = room,
                Username = username,
                Action = "online",
                TimestampUtc = DateTime.UtcNow
            });
        }
        catch { /* don't break room open if Rabbit is down */ }

        // Send this user's unread counts so the room list badges update
        await PushUnreadCountsAsync(username);
    }

    // -------------------------------------------------------------------------
    // Heartbeat — keeps _lastSeen fresh and pushes live status updates.
    // -------------------------------------------------------------------------

    public async Task Heartbeat(string username, string room)
    {
        if (string.IsNullOrWhiteSpace(username))
            return;

        username = username.Trim();
        room = string.IsNullOrWhiteSpace(room) ? "General" : room.Trim();

        _chatStateService.UpdateLastSeen(username, DateTime.UtcNow);

        await BroadcastPresenceAsync(room);

        // Publish heartbeat to RabbitMQ so other server instances also refresh
        // this user's LastSeen and push PresenceUpdated to their local clients.
        try
        {
            await _rabbitMqChatService.PublishPresenceAsync(new PresenceMessage
            {
                Room = room,
                Username = username,
                Action = "heartbeat",
                TimestampUtc = DateTime.UtcNow
            });
        }
        catch { /* don't break heartbeat if Rabbit is down */ }

        var isConnected = await _chatStateService.IsConnectedAsync();
        await Clients.Caller.SendAsync("RabbitStatusUpdated", isConnected);
    }

    // -------------------------------------------------------------------------
    // Typing indicators — broadcast to everyone else in the room.
    // -------------------------------------------------------------------------

    // Tracks who is currently typing: room → set of usernames
    private static readonly ConcurrentDictionary<string, HashSet<string>> _typingUsers
        = new(StringComparer.OrdinalIgnoreCase);
    private static readonly object _typingLock = new();

    public async Task StartTyping(string room, string username)
    {
        if (string.IsNullOrWhiteSpace(room) || string.IsNullOrWhiteSpace(username)) return;
        room = room.Trim();
        username = username.Trim();

        bool changed;
        lock (_typingLock)
        {
            var set = _typingUsers.GetOrAdd(room, _ => new HashSet<string>(StringComparer.OrdinalIgnoreCase));
            changed = set.Add(username);
        }

        if (changed)
            await BroadcastTypingAsync(room, username);
    }

    public async Task StopTyping(string room, string username)
    {
        if (string.IsNullOrWhiteSpace(room) || string.IsNullOrWhiteSpace(username)) return;
        room = room.Trim();
        username = username.Trim();

        bool changed;
        lock (_typingLock)
        {
            if (!_typingUsers.TryGetValue(room, out var set))
                return;
            changed = set.Remove(username);
        }

        if (changed)
            await BroadcastTypingAsync(room, username);
    }

    private async Task BroadcastTypingAsync(string room, string triggeringUser)
    {
        List<string> typers;
        lock (_typingLock)
        {
            typers = _typingUsers.TryGetValue(room, out var set)
                ? set.ToList()
                : new List<string>();
        }
        // Send to everyone in the room — the JS side filters out the current user
        await Clients.Group(room).SendAsync("TypingUpdated", new { room, typers });
    }

    // -------------------------------------------------------------------------
    // SendMessage — live message send from the composer.
    // -------------------------------------------------------------------------

    public async Task SendMessage(string room, string username, string message)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(message))
            return;

        room = string.IsNullOrWhiteSpace(room) ? "General" : room.Trim();
        username = username.Trim();
        message = message.Trim();

        if (!_chatStateService.CanUserAccessRoom(username, room))
            return;

        // Clear typing indicator for this user when they send
        await StopTyping(room, username);

        _chatStateService.UpdateLastSeen(username, DateTime.UtcNow);

        // Publish to RabbitMQ only. The RabbitMQ consumer (RabbitMqChatService)
        // is the single broadcast path — it calls Clients.Group(room).SendAsync
        // for ALL instances, so broadcasting here too causes every client to
        // receive the message twice.
        // The sender sees their own message immediately via optimistic rendering
        // in chat-heartbeat.js (trySend), so there is no visible delay.
        await _chatStateService.SendMessageAsync(room, username, message);
    }

    // -------------------------------------------------------------------------
    // OnDisconnectedAsync — fallback offline marking for crashes / network drops.
    // (The sendBeacon path handles deliberate tab closes faster.)
    // -------------------------------------------------------------------------

    public override async Task OnDisconnectedAsync(Exception? exception)
    {
        var username = Context.Items.TryGetValue(UsernameKey, out var u) ? u as string : null;
        var room = Context.Items.TryGetValue(RoomKey, out var r) ? r as string : "General";

        if (!string.IsNullOrWhiteSpace(username))
        {
            // Remove from connection registry
            lock (_registryLock)
            {
                if (_userConnections.TryGetValue(username, out var ids))
                {
                    ids.Remove(Context.ConnectionId);
                    if (ids.Count == 0)
                        _userConnections.Remove(username);
                }
            }

            // Remove from any typing sets
            if (!string.IsNullOrWhiteSpace(room))
            {
                lock (_typingLock)
                {
                    if (_typingUsers.TryGetValue(room, out var typers))
                        typers.Remove(username);
                }
                await BroadcastTypingAsync(room, username);
            }

            _chatStateService.UpdateLastSeen(username, DateTime.MinValue);

            if (!string.IsNullOrWhiteSpace(room))
            {
                await BroadcastPresenceAsync(room);

                // Publish offline event to RabbitMQ so other server instances mark
                // this user offline and push PresenceUpdated to their local clients.
                try
                {
                    await _rabbitMqChatService.PublishPresenceAsync(new PresenceMessage
                    {
                        Room = room,
                        Username = username,
                        Action = "offline",
                        TimestampUtc = DateTime.UtcNow
                    });
                }
                catch { /* don't break disconnect handling if Rabbit is down */ }
            }
        }

        await base.OnDisconnectedAsync(exception);
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    /// <summary>
    /// Pushes the current unread counts for all rooms to the specified user's
    /// connection so the room list badges stay current.
    /// </summary>
    private async Task PushUnreadCountsAsync(string username)
    {
        if (string.IsNullOrWhiteSpace(username)) return;

        var counts = _chatStateService.GetUnreadCounts(username.Trim());
        await Clients.Caller.SendAsync("UnreadCountsUpdated", counts);
    }

    private async Task BroadcastPresenceAsync(string room)
    {
        var members = _chatStateService
            .GetRoomMembers(room)
            .Select(m => new { username = m, isOnline = _chatStateService.IsUserOnline(m) })
            .ToList();

        await Clients.Group(room).SendAsync("PresenceUpdated", new
        {
            room,
            onlineCount = members.Count(m => m.isOnline),
            members
        });
    }
}